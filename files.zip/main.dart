import 'package:flutter/material.dart';
import 'screens/welcome_screen.dart';
import 'screens/login_screen.dart';
import 'screens/signup_screen.dart';
import 'screens/verification_screen.dart';
import 'screens/reset_password_screen.dart';
import 'screens/check_mail_screen.dart';
import 'screens/new_password_screen.dart';
import 'screens/reset_success_screen.dart';

void main() {
  runApp(const CampusBuddyApp());
}

class CampusBuddyApp extends StatelessWidget {
  const CampusBuddyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'CampusBuddy',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        fontFamily: 'Inter',
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF667EEA),
        ),
        useMaterial3: true,
      ),
      initialRoute: '/',
      routes: {
        '/': (context) => const WelcomeScreen(),
        '/login': (context) => const LoginScreen(),
        '/signup': (context) => const SignupScreen(),
        '/verification': (context) => const VerificationScreen(),
        '/reset-password': (context) => const ResetPasswordScreen(),
        '/check-mail': (context) => const CheckMailScreen(),
        '/new-password': (context) => const NewPasswordScreen(),
        '/reset-success': (context) => const ResetSuccessScreen(),
      },
    );
  }
}
